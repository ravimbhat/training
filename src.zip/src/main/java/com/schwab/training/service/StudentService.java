package com.schwab.training.service;

import com.schwab.training.model.Student;

import java.util.List;

public interface StudentService {

    public List getStudents();
    public Student addStudent(Student student);

    public String getCourseDetails(String courseId);
}
