package com.schwab.training.service;

import com.schwab.training.model.Student;
import com.schwab.training.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl implements StudentService{
    Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List getStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student addStudent(Student student) {
        logger.info("Calling the service class");
        return studentRepository.save(student);
    }

    @Override
    public String getCourseDetails(String courseId) {
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8081/coursedetails/" + courseId, String.class);
        return response.getBody();
    }

}
