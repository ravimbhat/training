package com.schwab.training.controller;

import com.schwab.training.model.Student;
import com.schwab.training.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentController {
    @Autowired
    private StudentService studentService;

    @GetMapping("/v1/students")
    public List<Student> getStudentList() {
        return studentService.getStudents();
    }

    @PostMapping("/v1/addstudent")
    public ResponseEntity<Student> addStudent(@RequestBody Student student){
        Student returned = studentService.addStudent(student);
        return new ResponseEntity<>(returned, HttpStatus.OK);
    }
}
