package com.schwab.training;


public class LoggingAspect {
}
