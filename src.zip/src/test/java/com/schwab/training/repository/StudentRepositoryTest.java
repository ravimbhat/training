package com.schwab.training.repository;

import com.schwab.training.model.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StudentRepositoryTest {

    @Autowired
    StudentRepository studentRepository;
    @Test
    public void saveStudent(){
        Calendar cal = Calendar.getInstance();
        cal.set(1990, 1, 1);

        Student student = new Student("Ravi", "Engg", "E0001", cal.getTime());
        Student returned = studentRepository.save(student);
        assertEquals(returned.getName(), student.getName());
    }

    @Test
    public void test_getStudentList(){
        List<Student> expectedList = saveStudents();
        List<Student> actualList = studentRepository.findAll();

        assertEquals(expectedList.size(), actualList.size());
        assertEquals(expectedList.get(0).getName(), actualList.get(0).getName());
    }

    private List<Student> saveStudents() {
        List<Student> list = new ArrayList<>();
        Student student = new Student("Ravi", "Engineering", "E0001", null);
        list.add(student);
        student = new Student("Gokul", "Engineering", "E0002", null);
        list.add(student);
        student = new Student("Sagar", "Engineering", "E0003", null);
        list.add(student);
        studentRepository.saveAll(list);
        return list;
    }
}
