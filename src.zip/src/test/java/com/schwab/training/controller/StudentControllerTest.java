package com.schwab.training.controller;

import com.schwab.training.model.Student;
import com.schwab.training.service.StudentService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StudentControllerTest {
    @InjectMocks
    StudentController studentController;
    @Mock
    StudentService studentService;
    @Test
    public void test_addStudent() {
        Student student = new Student("Ravi", "Engineering", "E0001", null);
        Mockito.when(studentService.addStudent(Mockito.any())).thenReturn(student);
        ResponseEntity<Student> response = studentController.addStudent(student);
        Mockito.verify(studentService).addStudent(Mockito.any());

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertEquals(student.getName(), response.getBody().getName());
    }
}