package com.schwab.training.service;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StudentServiceTest {
    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8081);

    @Autowired
    private StudentService studentService;
    @Test
    public void test_getCourseDetails() {
        String str = studentService.getCourseDetails("1");
        Assert.assertTrue(str.contains("1"));
    }

    @Test
    public void test_getCourseDetails_withMock() {
        wireMockRule.stubFor(
                WireMock.get(
                        WireMock.urlEqualTo("/coursedetails/1")).
                        willReturn(WireMock.aResponse().
                                withBody("{\"courseName\":\"Course 1 for students \", \"courseId\":1}")));
        // We're asserting if WireMock responded properly
//        Assert.assertThat(studentService.getCourseDetails("1")).isEqualTo("Hello World!");
        String str = studentService.getCourseDetails("1");
        Assert.assertTrue(str.contains("1"));
    }
}
